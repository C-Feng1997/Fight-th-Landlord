//#ifndef TEST_H
//#define TEST_H
//#include <QObject>
////class card{
////private:
////    int quanZhi;
////    int xuHao;
////};

//class Pokers:public QObject
//{
//    Q_OBJECT
//    Q_PROPERTY(void pokers READ pokers WRITE setPokers NOTIFY pokersChanged)
//public:


//    void pokers();
//    int pokersNumber[3];    //牌堆副本用于绑定qml
//};

//#endif // TEST_H
