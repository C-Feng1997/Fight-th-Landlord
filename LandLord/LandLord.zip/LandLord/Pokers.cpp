//#include "Pokers.h"
//#include <QRandomGenerator>

//void Pokers::pokers()
//{
//    for(int i=0; i<3;i++){
//            Pokers::pokersNumber[i] = i;
//    }

//}
